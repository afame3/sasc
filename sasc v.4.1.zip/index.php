	<?php include "views/navbar.phtml"; ?>	
